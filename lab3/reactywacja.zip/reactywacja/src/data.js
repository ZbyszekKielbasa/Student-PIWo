const startingHotels = [
    { id: 1, name: "Florence", hotel: "Harmony Hideaway Hotel", text:"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin dapibus\n" +
            "                            quis felis a venenatis. Suspendisse accumsan aliquam lorem, sit amet ultricies justo\n" +
            "                            tristique nec.",rating: "★★★★★", price: "100€/room" },
    { id: 2, name: "Madrid", hotel: "Serene Retreat", text:"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin dapibus\n" +
            "                            quis felis a venenatis. Suspendisse accumsan aliquam lorem, sit amet ultricies justo\n" +
            "                            tristique nec.",rating: "★★★★☆", price: "70€/room" },
    { id: 3, name: "Sintra", hotel: "Palm Springs", text:"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin dapibus\n" +
            "                            quis felis a venenatis. Suspendisse accumsan aliquam lorem, sit amet ultricies justo\n" +
            "                            tristique nec.",rating: "★★★★☆", price: "65€/room" },
    { id: 4, name: "Sienna", hotel: "Oasis Resort", text:"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin dapibus\n" +
            "                            quis felis a venenatis. Suspendisse accumsan aliquam lorem, sit amet ultricies justo\n" +
            "                            tristique nec.",rating: "★★★★★", price: "115€/room" },
]

export default startingHotels;
